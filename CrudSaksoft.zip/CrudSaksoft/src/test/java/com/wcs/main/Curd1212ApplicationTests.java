package com.wcs.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Curd1212ApplicationTests {

	@Test
	void contextLoads() {
	}

}
