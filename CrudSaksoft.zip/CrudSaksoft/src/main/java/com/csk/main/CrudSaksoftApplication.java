package com.csk.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudSaksoftApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(CrudSaksoftApplication.class, args);
		
		
	}

}
